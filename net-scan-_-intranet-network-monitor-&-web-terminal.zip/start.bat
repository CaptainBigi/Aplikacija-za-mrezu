@echo off
title NET-SCAN INTRANET MONITOR - SERVER
color 0A
cd /d "%~dp0"

echo =========================================================
echo       NET-SCAN INTRANET MONITOR - GLAVNI SERVER
echo       Created by N1ko7a (Za Sigurne Offline Mreze)
echo =========================================================
echo.

REM 0. Provera da li je korisnik pokrenuo direktno iz ZIP-a bez raspakivanja
echo %~dp0 | findstr /I "AppData\\Local\\Temp Temp1_ Temp2_" >nul
if %errorlevel% equ 0 goto inside_zip
goto check_node

:inside_zip
color 0C
echo =========================================================
echo  [UPOZORENJE] POKRENULI STE PROGRAM IZ ZIP ARHIVE!
echo =========================================================
echo.
echo  Windows ne moze da pokrene server direktno iz zip arhive.
echo.
echo  MOLIMO VAS DA URADITE SLEDECE:
echo  1. Kliknite desnim klikom na preuzeti ZIP fajl.
echo  2. Izaberite "Extract All..." (ili "Izdvoj sve...").
echo  3. Izaberite obican folder (npr. Desktop ili C:\NET-SCAN).
echo  4. Udjite u taj novi folder i tek onda pokrenite start.bat!
echo.
echo =========================================================
echo.
echo Pritisnite bilo koji taster za izlaz...
pause
exit /b 1

:check_node
echo [1/3] Proveravam Node.js okruzenje...

set NODE_EXE=

where node >nul 2>nul
if %errorlevel% equ 0 set NODE_EXE=node
if defined NODE_EXE goto node_found

if exist "C:\Program Files\nodejs\node.exe" set "NODE_EXE=C:\Program Files\nodejs\node.exe"
if defined NODE_EXE goto node_found

if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if defined NODE_EXE goto node_found

if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\nodejs\node.exe"
if defined NODE_EXE goto node_found

if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if defined NODE_EXE goto node_found

if exist "%~dp0node.exe" set "NODE_EXE=%~dp0node.exe"
if defined NODE_EXE goto node_found

:no_node
color 0C
echo.
echo =========================================================
echo  [GRESKA] Node.js NIJE PRONADJEN NA OVOM SISTEMU!
echo =========================================================
echo.
echo  Za rad ovog programa u zatvorenoj (offline) mrezi,
echo  potrebno je da instalirate Node.js na ovaj racunar.
echo.
echo  UPUTSTVO:
echo  1. Preuzmite instalaciju Node.js (LTS verzija, .msi instalacija):
echo     https://nodejs.org
echo  2. Prebacite instalacioni fajl preko USB-a na ovaj racunar.
echo  3. Pokrenite instalaciju (kliknite Next -> Next -> Finish).
echo  4. Ponovo pokrenite ovaj start.bat fajl.
echo.
echo =========================================================
echo.
echo Pritisnite bilo koji taster za zatvaranje...
pause
exit /b 1

:node_found
echo [OK] Node.js je prisutan: %NODE_EXE%
echo.

echo [2/3] Proveravam bazu podataka...
if not exist "data.json" goto copy_data
goto data_ready

:copy_data
if exist "netscan-data.json" copy /y "netscan-data.json" "data.json" >nul
echo [OK] Sinhronizovana baza u data.json.
goto data_ready

:data_ready
echo [OK] Baza data.json je spremna.
echo.

echo [3/3] Pokrecem NET-SCAN server na portu 3000...
echo.
echo =========================================================
echo  SERVER JE AKTIVAN I RADI!
echo.
echo  VAZNO:
echo  1. Ovaj crni prozor (CMD) MORA ostati otvoren dok server radi!
echo     Ako ga zatvorite na X, program ce prestati sa radom.
echo.
echo  2. Pristup sa OVOG racunara (otvorite u browseru):
echo     http://localhost:3000
echo.
echo  3. Pristup za kolege iz drugih kancelarija/zgrada:
echo     http://[VASA_IP_ADRESA]:3000
echo.
echo  4. Podaci za prijavu (Login):
echo     Korisnicko ime: Admin
echo     Lozinka:        123
echo =========================================================
echo.

if exist "server.js" goto run_server_js
if exist "server.ts" goto run_server_ts
goto run_npm

:run_server_js
echo Pokrecem gotov server.js...
echo.
"%NODE_EXE%" server.js
set SERVER_EXIT=%errorlevel%
goto server_stopped

:run_server_ts
echo [INFO] server.js nije pronadjen, pokrecem server.ts...
echo.
call npx tsx server.ts
set SERVER_EXIT=%errorlevel%
goto server_stopped

:run_npm
echo [INFO] Pokrecem preko npm...
echo.
call npm start
set SERVER_EXIT=%errorlevel%
goto server_stopped

:server_stopped
color 0C
echo.
echo =========================================================
echo  [GRESKA] Server se zaustavio (Exit kod: %SERVER_EXIT%).
echo.
echo  Moguci razlozi:
echo  1. Port 3000 je vec zauzet drugim programom ili prethodno
echo     pokrenutim NET-SCAN prozorom.
echo  2. Proverite Task Manager i zatvorite "node.exe" ako je aktivan.
echo =========================================================
echo.
echo Pritisnite bilo koji taster da zatvorite ovaj prozor...
pause
