import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Download,
  Terminal,
  Shield,
  Server,
  CheckCircle,
  Copy,
  Check,
  AlertTriangle,
  FolderGit2
} from 'lucide-react';

interface InstructionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstructionsModal: React.FC<InstructionsModalProps> = ({ isOpen, onClose }) => {
  const [copiedIpcmd, setCopiedIpcmd] = useState(false);

  if (!isOpen) return null;

  const downloadFile = (content: string, filename: string, type = 'text/plain') => {
    const blob = new Blob([content], { type: `${type};charset=utf-8;` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const startBatContent = `@echo off
title NET-SCAN INTRANET MONITOR - SERVER
color 0A
cd /d "%~dp0"

echo =========================================================
echo       NET-SCAN INTRANET MONITOR - GLAVNI SERVER
echo       Created by N1ko7a (Za Sigurne Offline Mreze)
echo =========================================================
echo.

REM 0. Provera da li je korisnik pokrenuo direktno iz ZIP-a bez raspakivanja
echo %~dp0 | findstr /I "AppData\\Local\\Temp Temp1_ Temp2_" >nul
if %errorlevel% equ 0 goto inside_zip
goto check_node

:inside_zip
color 0C
echo =========================================================
echo  [UPOZORENJE] POKRENULI STE PROGRAM IZ ZIP ARHIVE!
echo =========================================================
echo.
echo  Windows ne moze da pokrene server direktno iz zip arhive.
echo.
echo  MOLIMO VAS DA URADITE SLEDECE:
echo  1. Kliknite desnim klikom na preuzeti ZIP fajl.
echo  2. Izaberite "Extract All..." (ili "Izdvoj sve...").
echo  3. Izaberite obican folder (npr. Desktop ili C:\\NET-SCAN).
echo  4. Udjite u taj novi folder i tek onda pokrenite start.bat!
echo.
echo =========================================================
echo.
echo Pritisnite bilo koji taster za izlaz...
pause
exit /b 1

:check_node
echo [1/3] Proveravam Node.js okruzenje...

set NODE_EXE=

where node >nul 2>nul
if %errorlevel% equ 0 set NODE_EXE=node
if defined NODE_EXE goto node_found

if exist "C:\\Program Files\\nodejs\\node.exe" set "NODE_EXE=C:\\Program Files\\nodejs\\node.exe"
if defined NODE_EXE goto node_found

if exist "%ProgramFiles%\\nodejs\\node.exe" set "NODE_EXE=%ProgramFiles%\\nodejs\\node.exe"
if defined NODE_EXE goto node_found

if exist "%ProgramFiles(x86)%\\nodejs\\node.exe" set "NODE_EXE=%ProgramFiles(x86)%\\nodejs\\node.exe"
if defined NODE_EXE goto node_found

if exist "%LOCALAPPDATA%\\Programs\\nodejs\\node.exe" set "NODE_EXE=%LOCALAPPDATA%\\Programs\\nodejs\\node.exe"
if defined NODE_EXE goto node_found

if exist "%~dp0node.exe" set "NODE_EXE=%~dp0node.exe"
if defined NODE_EXE goto node_found

:no_node
color 0C
echo.
echo =========================================================
echo  [GRESKA] Node.js NIJE PRONADJEN NA OVOM SISTEMU!
echo =========================================================
echo.
echo  Za rad ovog programa u zatvorenoj (offline) mrezi,
echo  potrebno je da instalirate Node.js na ovaj racunar.
echo.
echo  UPUTSTVO:
echo  1. Preuzmite instalaciju Node.js (LTS verzija, .msi instalacija):
echo     https://nodejs.org
echo  2. Prebacite instalacioni fajl preko USB-a na ovaj racunar.
echo  3. Pokrenite instalaciju (kliknite Next -> Next -> Finish).
echo  4. Ponovo pokrenite ovaj start.bat fajl.
echo.
echo =========================================================
echo.
echo Pritisnite bilo koji taster za zatvaranje...
pause
exit /b 1

:node_found
echo [OK] Node.js je prisutan: %NODE_EXE%
echo.

echo [2/3] Proveravam bazu podataka...
if not exist "data.json" goto copy_data
goto data_ready

:copy_data
if exist "netscan-data.json" copy /y "netscan-data.json" "data.json" >nul
echo [OK] Sinhronizovana baza u data.json.
goto data_ready

:data_ready
echo [OK] Baza data.json je spremna.
echo.

echo [3/3] Pokrecem NET-SCAN server na portu 3000...
echo.
echo =========================================================
echo  SERVER JE AKTIVAN I RADI!
echo.
echo  VAZNO:
echo  1. Ovaj crni prozor (CMD) MORA ostati otvoren dok server radi!
echo     Ako ga zatvorite na X, program ce prestati sa radom.
echo.
echo  2. Pristup sa OVOG racunara (otvorite u browseru):
echo     http://localhost:3000
echo.
echo  3. Pristup za kolege iz drugih kancelarija/zgrada:
echo     http://[VASA_IP_ADRESA]:3000
echo.
echo  4. Podaci za prijavu (Login):
echo     Korisnicko ime: Admin
echo     Lozinka:        123
echo =========================================================
echo.

if exist "server.js" goto run_server_js
if exist "server.ts" goto run_server_ts
goto run_npm

:run_server_js
echo Pokrecem gotov server.js...
echo.
"%NODE_EXE%" server.js
set SERVER_EXIT=%errorlevel%
goto server_stopped

:run_server_ts
echo [INFO] server.js nije pronadjen, pokrecem server.ts...
echo.
call npx tsx server.ts
set SERVER_EXIT=%errorlevel%
goto server_stopped

:run_npm
echo [INFO] Pokrecem preko npm...
echo.
call npm start
set SERVER_EXIT=%errorlevel%
goto server_stopped

:server_stopped
color 0C
echo.
echo =========================================================
echo  [GRESKA] Server se zaustavio (Exit kod: %SERVER_EXIT%).
echo.
echo  Moguci razlozi:
echo  1. Port 3000 je vec zauzet drugim programom ili prethodno
echo     pokrenutim NET-SCAN prozorom.
echo  2. Proverite Task Manager i zatvorite "node.exe" ako je aktivan.
echo =========================================================
echo.
echo Pritisnite bilo koji taster da zatvorite ovaj prozor...
pause
`;

  const installStartupBatContent = `@echo off
title NET-SCAN - Instalacija u Windows Startup (Automatsko Pokretanje)
color 0B
cd /d "%~dp0"

echo =========================================================
echo   NET-SCAN INTRANET MONITOR - AUTOMATSKO POKRETANJE
echo =========================================================
echo.
echo Ovaj program ce podesiti da se NET-SCAN server automatski
echo pokrene pri svakom paljenju ovog racunara.
echo.

set "STARTUP_FOLDER=%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
set "SHORTCUT=%STARTUP_FOLDER%\\NET-SCAN_Server.bat"

echo Kreiram automatsku skriptu u folderu:
echo %STARTUP_FOLDER%
echo.

(
    echo @echo off
    echo cd /d "%~dp0"
    echo start "" "%~dp0start.bat"
) > "%SHORTCUT%"

if exist "%SHORTCUT%" (
    color 0A
    echo =========================================================
    echo [USPESNO PODESENO]
    echo NET-SCAN server ce se sam pokrenuti svaki put kada
    echo se racunar upali ili restartuje!
    echo =========================================================
) else (
    color 0C
    echo =========================================================
    echo [GRESKA] Nije uspelo kreiranje skripte u Startup folderu.
    echo Pokrenite ovaj fajl kao Administrator.
    echo =========================================================
)

echo.
pause
`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-[#181b24] border border-[#262a36] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* HEADER */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#262a36] bg-[#14161f]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                NET-SCAN — Korisničko Uputstvo (Offline Mreža)
              </h3>
              <p className="text-[11px] text-gray-400">Podešavanje glavnog servera i pristup kolega</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* BODY */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-gray-300 leading-relaxed">
          {/* QUICK DOWNLOADS BANNER */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-blue-950/40 border border-emerald-500/30 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="font-bold text-sm text-emerald-400 flex items-center gap-2">
                <Download className="w-4 h-4" /> Preuzimanje Fajlova za Pokretanje
              </div>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Preuzmite skripte za vaš offline Windows računar (ako ih nemate u folderu):
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <a
                href="/NET-SCAN-OFFLINE.zip"
                download="NET-SCAN-OFFLINE.zip"
                className="px-3 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-black font-extrabold rounded-lg font-mono text-[11px] transition-all shadow-md flex items-center gap-1.5"
                title="Preuzmite kompletan spakovan paket (server.js + dist + start.bat)"
              >
                <Download className="w-3.5 h-3.5" /> Gotov Offline Paket (.ZIP)
              </a>
              <button
                onClick={() => downloadFile(startBatContent, 'start.bat', 'application/x-bat')}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-mono text-[11px] font-bold transition-all shadow-sm flex items-center gap-1.5"
                title="Preuzmite samo start.bat skriptu"
              >
                <Terminal className="w-3.5 h-3.5" /> start.bat
              </button>
              <button
                onClick={() => downloadFile(installStartupBatContent, 'install_startup.bat', 'application/x-bat')}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-mono text-[11px] font-bold transition-all shadow-sm flex items-center gap-1.5"
                title="Preuzmite install_startup.bat skriptu"
              >
                <Server className="w-3.5 h-3.5" /> install_startup.bat
              </button>
            </div>
          </div>

          {/* 1. KAKO SE POKRECE APLIKACIJA */}
          <div className="space-y-2">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 flex items-center justify-center text-xs">
                1
              </span>
              Kako se pokreće aplikacija na vašem računaru (serveru)?
            </h4>
            <div className="pl-7 space-y-1.5 text-gray-300">
              <p>
                • Dvoklikom pokrenite fajl <strong className="text-emerald-400 font-mono">start.bat</strong>.
              </p>
              <p>
                • <strong>Opciono:</strong> Ako želite da se aplikacija pali sama pri svakom paljenju računara, pokrenite fajl <strong className="text-blue-400 font-mono">install_startup.bat</strong>.
              </p>
              <p>
                • Na ekranu će se otvoriti crni prozor (CMD) i ispisati da je server pokrenut. <span className="text-amber-300 font-semibold">Taj prozor mora ostati otvoren</span>, jer je to "mozak" vaše aplikacije. Ukoliko ga zatvorite na X, aplikacija će prestati sa radom.
              </p>
            </div>
          </div>

          {/* 2. KAKO PRISTUPITI APLIKACIJI */}
          <div className="space-y-2">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 flex items-center justify-center text-xs">
                2
              </span>
              Kako pristupiti aplikaciji (preko browsera)?
            </h4>
            <div className="pl-7 space-y-1.5 text-gray-300">
              <p>
                • Na ovom (glavnom) računaru otvorite Chrome, Firefox ili Edge i ukucajte:
              </p>
              <div className="bg-[#0f1117] p-2.5 rounded-lg border border-[#262a36] font-mono text-emerald-400 text-xs inline-block">
                http://localhost:3000
              </div>
            </div>
          </div>

          {/* OBAVEZNO PODESAVANJE ZA KOLEGE */}
          <div className="bg-[#14161f] border border-[#2b3142] rounded-xl p-4 space-y-3">
            <div className="font-bold text-amber-400 text-xs uppercase tracking-wider flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              Podešavanje da bi kolege mogle da pristupe sa svojih računara
            </div>
            <p className="text-gray-300 text-xs">
              Kolege iz drugih kancelarija/zgrada u vašoj zatvorenoj mreži <strong className="text-white">ne moraju ništa da instaliraju</strong>. Dovoljno je da ovaj vaš računar glumi server:
            </p>

            <div className="space-y-2 pt-1 border-t border-[#262a36]">
              <div>
                <strong className="text-white">KORAK A: Saznajte vašu fiksnu IP adresu</strong>
                <ol className="list-decimal list-inside text-gray-400 mt-1 space-y-0.5">
                  <li>Otvorite Start i ukucajte CMD.</li>
                  <li>
                    Ukucajte komandu: <code className="text-emerald-400 font-mono">ipconfig</code> i pritisnite Enter.
                  </li>
                  <li>
                    Pronađite red <em>"IPv4 Address"</em> (na primer: <code className="text-white font-mono">11.29.50.15</code>).
                  </li>
                </ol>
                <div className="mt-2 text-gray-300 bg-[#0f1117] p-2 rounded border border-[#262a36]">
                  Vaše kolege na svom računaru u Chrome kucaju:{' '}
                  <span className="text-emerald-400 font-mono font-bold">http://[VASA_IP_ADRESA]:3000</span>
                </div>
              </div>

              <div className="pt-2">
                <strong className="text-white">KORAK B: Otključavanje porta 3000 kroz Windows Firewall</strong>
                <ol className="list-decimal list-inside text-gray-400 mt-1 space-y-0.5">
                  <li>Otvorite Start i ukucajte: <em>Windows Defender Firewall with Advanced Security</em></li>
                  <li>Sa leve strane kliknite na <strong>Inbound Rules (Ulazna pravila)</strong>.</li>
                  <li>Sa desne strane kliknite na <strong>New Rule... (Novo pravilo)</strong>.</li>
                  <li>Izaberite <strong>Port</strong> &gt; Next.</li>
                  <li>Izaberite <strong>TCP</strong>, a u polje unosite port: <strong className="text-emerald-400 font-mono">3000</strong> &gt; Next.</li>
                  <li>Izaberite <strong>Allow the connection</strong> &gt; Next &gt; Next.</li>
                  <li>Nazovite ga <em>"NET-SCAN Server"</em> i kliknite Finish.</li>
                </ol>
              </div>
            </div>
          </div>

          {/* 3. PODACI ZA PRIJAVU */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 flex items-center justify-center text-xs">
                3
              </span>
              Podaci za prijavu (Login)
            </h4>
            <div className="pl-7 text-gray-300">
              Korisničko ime: <strong className="text-white font-mono">Admin</strong> &nbsp;|&nbsp; Lozinka: <strong className="text-white font-mono">123</strong>
            </div>
          </div>

          {/* 4. NOVA UGRADJENA CMD KONZOLA */}
          <div className="space-y-1.5 bg-emerald-950/20 border border-emerald-500/30 p-3.5 rounded-xl">
            <h4 className="font-bold text-sm text-emerald-400 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              Kako radi nova Ugrađena CMD Konzola?
            </h4>
            <p className="text-gray-300">
              Kada bilo koja kolega sa svog računara klikne na dugme <strong>PING</strong>, <strong>TRACERT</strong> ili <strong>TELNET</strong>, prozor konzole se otvara <strong>isključivo u njihovom browseru</strong>.
            </p>
            <p className="text-emerald-300">
              ✓ Nema otvaranja prozora na vašem glavnom serverskom računaru!<br />
              ✓ Kolegama se ne preuzima nikakav .bat fajl — sve ide uživo kroz web interfejs!
            </p>
          </div>

          {/* 5. GDE SE CUVAJU PODACI */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-sm text-white flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-400 flex items-center justify-center text-xs">
                4
              </span>
              Baza i Bekapi (data.json)
            </h4>
            <div className="pl-7 space-y-1 text-gray-400">
              <p>
                • Svi podaci se automatski čuvaju u fajlu <strong className="text-white font-mono">data.json</strong> u folderu aplikacije.
              </p>
              <p>
                • Svakog dana u pozadini aplikacija pravi kopiju u folder <strong className="text-white font-mono">backups/data_backup_YYYY-MM-DD.json</strong>.
              </p>
              <p>
                • Bekapi stariji od 14 dana se automatski čiste kako ne bi zauzimali prostor na disku.
              </p>
            </div>
          </div>
        </div>

        {/* FOOTER */}
        <div className="px-6 py-3.5 border-t border-[#262a36] bg-[#14161f] flex items-center justify-between">
          <div className="text-[11px] text-gray-500">
            Specijalno prilagođeno za sigurne (offline) mreže • Created by <strong className="text-emerald-400">N1ko7a</strong>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors"
          >
            U redu, razumem
          </button>
        </div>
      </div>
    </div>
  );
};
